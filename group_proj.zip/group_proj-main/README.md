# group_proj

## Description 
this is a group project from my group consiting of Python 

## Collaborators
